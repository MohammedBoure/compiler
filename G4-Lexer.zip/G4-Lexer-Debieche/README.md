We are: Debieche Amine, Bouremouz Mohammed, Meriche Chemseddine the authers of this project.

All the prorejct source code is in ./src/

we highly recommand visiting our github repository where we hosted thi project, link:
https://github.com/MohammedBoure/compiler

Inthere, you will find the full developement history. Also, this file will be easier to read since it's writen in MarkDown



# How to compile and run
Compile with:
```bash
gcc lexer.c -o lexer
```

Run with:
```bash
./lexer input [-o output]
```

examples:
```bash
./lexer input.c
./lexer input.c -o output
```


# Exercise to Filename Mapping
This mapping tells where each exercise live in the code

- Phase 1
  - Exercise 1 → src/exo1.c
  - Exercise 2 
    - Struct Token → src/lexer_utils.c
    - Test program → src/exo2.c

- Phase 2
  - Exercise 3 → src/lexer_utils.c
  - Exercise 4 → src/lexer_utils.c
  - Exercise 5 → src/lexer_utils.c

- Phase 3
  - Exercise 6 → src/lexer.c

- Phase 4
  - Exercise 7 → src/lexer.c
  - Exercise 8 → src/lexer.c
  - Exercise 9 → src/lexer.c
  - Exercise 10 → src/lexer.c

- Phase 5
  - Exercise 11 → src/lexer.c
  - Exercise 12 → src/lexer.c
